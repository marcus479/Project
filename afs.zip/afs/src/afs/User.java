
package afs;

import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

// ABSTRACTION: User class cannot be instantiated directly
public abstract class User {
    // ENCAPSULATION: Protected fields accessible by subclasses
    protected String id;
    protected String password;
    protected String name;
    protected String role;

    public User(String id, String password, String name, String role) {
        this.id = id;
        this.password = password;
        this.name = name;
        this.role = role;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getRole() { return role; }

    // POLYMORPHISM: Each child class will implement their own dashboard
    public abstract void showDashboard();

    // Common method to edit profile (Student/Lecturer/Leader all use this)
    public void editProfile(JFrame parentFrame) {
        String newName = JOptionPane.showInputDialog(parentFrame, "Enter new name:", name);
        String newPass = JOptionPane.showInputDialog(parentFrame, "Enter new password:", password);
        
        if (newName != null && newPass != null && !newName.isEmpty() && !newPass.isEmpty()) {
            List<String> users = FileHandler.readFile("users.txt");
            List<String> updatedUsers = new ArrayList<>();
            
            for (String line : users) {
                String[] parts = line.split(",");
                if (parts[0].equals(this.id)) {
                    // Update this user's record
                    updatedUsers.add(parts[0] + "," + newPass + "," + parts[2] + "," + newName);
                    this.name = newName;
                    this.password = newPass;
                } else {
                    updatedUsers.add(line);
                }
            }
            FileHandler.overwriteFile("users.txt", updatedUsers);
            JOptionPane.showMessageDialog(parentFrame, "Profile updated successfully!");
        }
    }
}