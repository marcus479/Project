
package afs;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class Lecturer extends User {

    public Lecturer(String id, String password, String name) {
        super(id, password, name, "Lecturer");
    }

    @Override
    public void showDashboard() {
        JFrame frame = new JFrame("Lecturer Dashboard - " + this.name);
        frame.setSize(700, 500);
        frame.setLayout(new BorderLayout());

        // 1. Header Title
        JLabel lblTitle = new JLabel("Lecturer Management Panel", SwingConstants.CENTER);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblTitle.setForeground(new Color(50, 50, 50));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        frame.add(lblTitle, BorderLayout.NORTH);

        // 2. Buttons Panel (Grid Layout with spacing)
        JPanel btnPanel = new JPanel(new GridLayout(4, 1, 15, 15));
        btnPanel.setBorder(BorderFactory.createEmptyBorder(20, 60, 40, 60)); // Add padding margins

        JButton btnDesign = new JButton("Design Assessment");
        JButton btnGrading = new JButton("Key In Marks & Feedback");
        JButton btnProfile = new JButton("Edit Profile");
        JButton btnLogout = new JButton("Logout");

        // Apply Styling (Purple Theme)
        Color themeColor = new Color(147, 112, 219); // Medium Purple
        styleButton(btnDesign, themeColor);
        styleButton(btnGrading, themeColor);
        styleButton(btnProfile, themeColor);
        styleButton(btnLogout, themeColor);

        // --- Feature: Design Assessment ---
        btnDesign.addActionListener(e -> {
            String mod = JOptionPane.showInputDialog(frame, "Enter Module Code:");
            String type = JOptionPane.showInputDialog(frame, "Enter Assessment Type (e.g., Quiz, Assignment):");
            if (mod != null && type != null) {
                FileHandler.appendToFile("assessments.txt", mod + "," + type);
                JOptionPane.showMessageDialog(frame, "Assessment Designed Successfully!");
            }
        });

        // --- Feature: Key In Marks ---
        btnGrading.addActionListener(e -> {
            JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
            JTextField txtStudent = new JTextField();
            JTextField txtMod = new JTextField();
            JTextField txtType = new JTextField();
            JTextField txtMark = new JTextField();
            JTextField txtFeedback = new JTextField();

            panel.add(new JLabel("Student ID:")); panel.add(txtStudent);
            panel.add(new JLabel("Module Code:")); panel.add(txtMod);
            panel.add(new JLabel("Assessment Type:")); panel.add(txtType);
            panel.add(new JLabel("Marks (0-100):")); panel.add(txtMark);
            panel.add(new JLabel("Feedback:")); panel.add(txtFeedback);

            int res = JOptionPane.showConfirmDialog(frame, panel, "Enter Student Grades", JOptionPane.OK_CANCEL_OPTION);
            if (res == JOptionPane.OK_OPTION) {
                try {
                    double m = Double.parseDouble(txtMark.getText());
                    if (m < 0 || m > 100) throw new NumberFormatException();
                    
                    // Determine Grade using Default Grading System logic
                    // (For distinction, you could load the file here to get precise grade)
                    String grade = (m >= 80) ? "A+" : (m >= 75) ? "A" : (m >= 50) ? "Pass" : "Fail"; 
                    
                    String record = txtStudent.getText() + "," + txtMod.getText() + "," + 
                                  txtType.getText() + "," + m + "," + txtFeedback.getText() + "," + grade;
                                  
                    FileHandler.appendToFile("grades.txt", record);
                    JOptionPane.showMessageDialog(frame, "Marks Saved! Calculated Grade: " + grade);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Error: Marks must be a number between 0 and 100.");
                }
            }
        });

        // --- Feature: Edit Profile ---
        btnProfile.addActionListener(e -> editProfile(frame));

        // --- Feature: Logout ---
        btnLogout.addActionListener(e -> {
            frame.dispose();
            new Login().start();
        });

        btnPanel.add(btnDesign);
        btnPanel.add(btnGrading);
        btnPanel.add(btnProfile);
        btnPanel.add(btnLogout);

        frame.add(btnPanel, BorderLayout.CENTER);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void styleButton(JButton btn, Color color) {
        btn.setFont(new Font("SansSerif", Font.BOLD, 16));
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(color.darker(), 1),
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
    }
}
