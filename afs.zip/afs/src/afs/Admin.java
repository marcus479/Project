
package afs;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern; // Import for Regex

public class Admin extends User {
    
    private static final String BACKGROUND_IMAGE_PATH = "p1.jpg"; 

    public Admin(String id, String password, String name) {
        super(id, password, name, "Admin");
    }

    @Override
    public void showDashboard() {
        JFrame frame = new JFrame("Admin Dashboard - " + this.name);
        frame.setSize(900, 600);
        frame.setLayout(new BorderLayout());

        // 1. Custom Background
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    Image img = ImageIO.read(new File(BACKGROUND_IMAGE_PATH));
                    g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
                } catch (IOException e) {
                    g.setColor(new Color(70, 130, 180));
                    g.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        backgroundPanel.setLayout(new BorderLayout());
        frame.setContentPane(backgroundPanel);

        // 2. Sidebar
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(0, 0, 0, 120)); 
        sidebar.setPreferredSize(new Dimension(220, frame.getHeight()));
        sidebar.setBorder(BorderFactory.createEmptyBorder(30, 20, 30, 20)); 

        // Header
        JLabel lblHeader = new JLabel("<html>System<br>Admin</html>");
        lblHeader.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblHeader.setForeground(Color.WHITE);
        lblHeader.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Buttons
        JButton btnManageUsers = createSidebarButton("Manage Users");
        JButton btnAssign = createSidebarButton("Assign Lecturer"); 
        JButton btnGrading = createSidebarButton("Grading System");
        JButton btnCreateClass = createSidebarButton("Create Class");
        JButton btnLogout = createSidebarButton("Logout");

        btnLogout.setBackground(new Color(220, 50, 50)); 
        btnLogout.setForeground(Color.WHITE);
        
        // Add to sidebar
        sidebar.add(lblHeader);
        sidebar.add(Box.createVerticalStrut(30));
        sidebar.add(btnManageUsers);
        sidebar.add(Box.createVerticalStrut(15));
        sidebar.add(btnAssign); 
        sidebar.add(Box.createVerticalStrut(15));
        sidebar.add(btnGrading);
        sidebar.add(Box.createVerticalStrut(15));
        sidebar.add(btnCreateClass);
        sidebar.add(Box.createVerticalGlue());
        sidebar.add(btnLogout);

        backgroundPanel.add(sidebar, BorderLayout.WEST);

        // --- ACTIONS ---
        btnManageUsers.addActionListener(e -> openUserCrudWindow(frame));
        btnAssign.addActionListener(e -> openAssignLecturerWindow(frame)); 
        btnGrading.addActionListener(e -> openGradingWindow(frame));

        // --- CREATE CLASS ---
        btnCreateClass.addActionListener(e -> {
            String className = promptForInput(frame, "Enter Class Name (e.g., APU-IT-112025):");
            if (className == null) return; 

            String module = promptForInput(frame, "Enter Module Code (e.g., OODJ):");
            if (module == null) return; 

            FileHandler.appendToFile("classes.txt", className + "," + module);
            JOptionPane.showMessageDialog(frame, "Class Created Successfully!");
        });

        btnLogout.addActionListener(e -> {
            frame.dispose();
            new Login().start();
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    // --- HELPER: Validates input loop ---
    private String promptForInput(JFrame parent, String message) {
        while (true) {
            String input = JOptionPane.showInputDialog(parent, message);
            if (input == null) return null; // Cancelled
            if (!input.trim().isEmpty()) return input.trim();
            JOptionPane.showMessageDialog(parent, "Input cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JButton createSidebarButton(String text) {
        JButton btn = new JButton(text);
        btn.setMaximumSize(new Dimension(200, 40));
        btn.setFont(new Font("SansSerif", Font.BOLD, 14));
        btn.setBackground(new Color(50, 50, 50)); 
        btn.setForeground(Color.WHITE); 
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(100, 100, 100)); 
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                if (text.equals("Logout")) btn.setBackground(new Color(220, 50, 50));
                else btn.setBackground(new Color(50, 50, 50)); 
            }
        });
        return btn;
    }

    // ==========================================
    // 1. USER CRUD LOGIC (STRICTER VALIDATION)
    // ==========================================
    private void openUserCrudWindow(JFrame parent) {
        JDialog dialog = new JDialog(parent, "Manage End Users", true);
        dialog.setSize(700, 500);
        dialog.setLayout(new BorderLayout());

        String[] columns = {"User ID", "Password", "Role", "Name"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        
        List<String> users = FileHandler.readFile("users.txt");
        for (String line : users) {
            String[] parts = line.split(",");
            if(parts.length >= 4) model.addRow(parts);
        }

        JPanel crudPanel = new JPanel();
        JButton btnAdd = new JButton("Create New");
        JButton btnEdit = new JButton("Update Selected");
        JButton btnDelete = new JButton("Delete Selected");
        JButton btnExit = new JButton("Exit");

        // CREATE USER
        btnAdd.addActionListener(e -> {
            JPanel panel = new JPanel(new GridLayout(4, 2));
            JTextField txtId = new JTextField();
            JTextField txtPass = new JTextField();
            JTextField txtName = new JTextField();
            JComboBox<String> cbRole = new JComboBox<>(new String[]{"AcademicLeader", "Lecturer", "Student"});
            
            panel.add(new JLabel("ID:")); panel.add(txtId);
            panel.add(new JLabel("Password:")); panel.add(txtPass);
            panel.add(new JLabel("Name:")); panel.add(txtName);
            panel.add(new JLabel("Role:")); panel.add(cbRole);

            int result = JOptionPane.showConfirmDialog(dialog, panel, "Create User", JOptionPane.OK_CANCEL_OPTION);
            
            if (result == JOptionPane.OK_OPTION) {
                String id = txtId.getText().trim();
                String pass = txtPass.getText().trim();
                String name = txtName.getText().trim();
                String role = (String) cbRole.getSelectedItem();

                // 1. EMPTY FIELD CHECK
                if (id.isEmpty() || pass.isEmpty() || name.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "All fields are required!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // 2. ID DUPLICATE CHECK
                for(int i=0; i<model.getRowCount(); i++) {
                    if(model.getValueAt(i,0).equals(id)) {
                        JOptionPane.showMessageDialog(dialog, "User ID already exists!", "Duplicate Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                // 3. STUDENT ID FORMAT CHECK
                if (role.equals("Student")) {
                    if (!Pattern.matches("^TP\\d{6}$", id)) {
                        JOptionPane.showMessageDialog(dialog, "Student ID must start with 'TP' followed by 6 digits.", "Invalid ID", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                // 4. NEW NAME VALIDATION (Letters Only)
                // Regex: [a-zA-Z\s]+ ensures only letters and spaces allowed
                if (!name.matches("[a-zA-Z\\s]+")) {
                    JOptionPane.showMessageDialog(dialog, "Name must contain only letters (No numbers allowed).", "Invalid Name", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // 5. NEW PASSWORD COMPLEXITY CHECK
                // Rule: Min 8 chars, 1 Upper, 1 Lower, 1 Number, 1 Special
                if (pass.length() < 8) {
                    JOptionPane.showMessageDialog(dialog, "Password must be at least 8 characters long.", "Weak Password", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                // Regex breakdown: (?=.*[a-z]) lower, (?=.*[A-Z]) upper, (?=.*[0-9]) digit, (?=.*[^a-zA-Z0-9]) special
                if (!pass.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^a-zA-Z\\d]).+$")) {
                    JOptionPane.showMessageDialog(dialog, 
                        "Password must contain:\n- At least 1 Uppercase Letter\n- At least 1 Lowercase Letter\n- At least 1 Number\n- At least 1 Special Symbol", 
                        "Weak Password", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Save if all valid
                String row = id + "," + pass + "," + role + "," + name;
                FileHandler.appendToFile("users.txt", row);
                model.addRow(row.split(","));
                JOptionPane.showMessageDialog(dialog, "User Created Successfully!");
            }
        });

        // UPDATE USER (Apply same validation)
        btnEdit.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row != -1) {
                JTextField txtPass = new JTextField((String)model.getValueAt(row, 1));
                JTextField txtName = new JTextField((String)model.getValueAt(row, 3));
                Object[] msg = {"New Password:", txtPass, "New Name:", txtName};

                int result = JOptionPane.showConfirmDialog(dialog, msg, "Update", JOptionPane.OK_CANCEL_OPTION);
                if(result == JOptionPane.OK_OPTION) {
                    String newPass = txtPass.getText().trim();
                    String newName = txtName.getText().trim();

                    if (newPass.isEmpty() || newName.isEmpty()) {
                        JOptionPane.showMessageDialog(dialog, "Fields cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // Validate Name (Update)
                    if (!newName.matches("[a-zA-Z\\s]+")) {
                        JOptionPane.showMessageDialog(dialog, "Name must contain only letters (No numbers allowed).", "Invalid Name", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // Validate Password (Update)
                    if (newPass.length() < 8 || !newPass.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^a-zA-Z\\d]).+$")) {
                        JOptionPane.showMessageDialog(dialog, 
                            "Password must contain 8+ chars, Uppercase, Lowercase, Number & Symbol.", 
                            "Weak Password", JOptionPane.WARNING_MESSAGE);
                        return;
                    }

                    model.setValueAt(newPass, row, 1);
                    model.setValueAt(newName, row, 3);
                    saveTableDataToFile(model, "users.txt");
                    JOptionPane.showMessageDialog(dialog, "User Updated Successfully!");
                }
            } else {
                JOptionPane.showMessageDialog(dialog, "Please select a user to update.");
            }
        });

        // DELETE
        btnDelete.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row != -1 && JOptionPane.showConfirmDialog(dialog, "Delete User?", "Confirm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                model.removeRow(row);
                saveTableDataToFile(model, "users.txt");
            }
        });
        
        btnExit.addActionListener(e -> dialog.dispose());

        crudPanel.add(btnAdd);
        crudPanel.add(btnEdit);
        crudPanel.add(btnDelete);
        crudPanel.add(btnExit);
        dialog.add(new JScrollPane(table), BorderLayout.CENTER);
        dialog.add(crudPanel, BorderLayout.SOUTH);
        dialog.setLocationRelativeTo(parent);
        dialog.setVisible(true);
    }

    // ==========================================
    // 2. ASSIGN LECTURER TO LEADER 
    // ==========================================
    private void openAssignLecturerWindow(JFrame parent) {
        JPanel panel = new JPanel(new GridLayout(2, 2, 10, 10));
        JComboBox<String> cbLeaders = new JComboBox<>();
        JComboBox<String> cbLecturers = new JComboBox<>();
        
        List<String> users = FileHandler.readFile("users.txt");
        for (String line : users) {
            String[] parts = line.split(",");
            if (parts.length >= 4) {
                if (parts[2].equals("AcademicLeader")) cbLeaders.addItem(parts[0] + " - " + parts[3]);
                if (parts[2].equals("Lecturer")) cbLecturers.addItem(parts[0] + " - " + parts[3]);
            }
        }
        
        panel.add(new JLabel("Select Academic Leader:"));
        panel.add(cbLeaders);
        panel.add(new JLabel("Select Lecturer:"));
        panel.add(cbLecturers);
        
        int result = JOptionPane.showConfirmDialog(parent, panel, "Assign Lecturer to Leader", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String leaderRaw = (String) cbLeaders.getSelectedItem();
            String lecturerRaw = (String) cbLecturers.getSelectedItem();
            
            if (leaderRaw != null && lecturerRaw != null) {
                String leaderId = leaderRaw.split(" - ")[0];
                String lecturerId = lecturerRaw.split(" - ")[0];
                FileHandler.appendToFile("leader_lecturers.txt", leaderId + "," + lecturerId);
                JOptionPane.showMessageDialog(parent, "Assignment Successful!\nLecturer " + lecturerId + " assigned to Leader " + leaderId);
            }
        }
    }

    // ==========================================
    // 3. GRADING SYSTEM LOGIC 
    // ==========================================
    private void openGradingWindow(JFrame parent) {
        JDialog dialog = new JDialog(parent, "Grading System", true);
        dialog.setSize(700, 500);
        
        checkAndInitGradingDefaults();

        String[] cols = {"Min Mark", "Max Mark", "Grade", "Point", "Classification"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        JTable table = new JTable(model);

        List<String> lines = FileHandler.readFile("grading_default.txt");
        for(String line : lines) model.addRow(line.split(","));

        JPanel pnl = new JPanel();
        JButton btnUpdate = new JButton("Update Selected"); 
        JButton btnReset = new JButton("Reset Defaults");
        JButton btnExit = new JButton("Exit"); 

        btnUpdate.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row != -1) {
                JTextField txtMin = new JTextField((String)model.getValueAt(row, 0));
                JTextField txtMax = new JTextField((String)model.getValueAt(row, 1));
                JTextField txtGrade = new JTextField((String)model.getValueAt(row, 2));
                JTextField txtPoint = new JTextField((String)model.getValueAt(row, 3));
                JTextField txtClass = new JTextField((String)model.getValueAt(row, 4));
                
                JPanel editPnl = new JPanel(new GridLayout(5, 2));
                editPnl.add(new JLabel("Min Mark:")); editPnl.add(txtMin);
                editPnl.add(new JLabel("Max Mark:")); editPnl.add(txtMax);
                editPnl.add(new JLabel("Grade:")); editPnl.add(txtGrade);
                editPnl.add(new JLabel("Point:")); editPnl.add(txtPoint);
                editPnl.add(new JLabel("Classification:")); editPnl.add(txtClass);
                
                if (JOptionPane.showConfirmDialog(dialog, editPnl, "Edit Grade", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                    model.setValueAt(txtMin.getText(), row, 0);
                    model.setValueAt(txtMax.getText(), row, 1);
                    model.setValueAt(txtGrade.getText(), row, 2);
                    model.setValueAt(txtPoint.getText(), row, 3);
                    model.setValueAt(txtClass.getText(), row, 4);
                    saveTableDataToFile(model, "grading_default.txt");
                    JOptionPane.showMessageDialog(dialog, "Updated & Saved!");
                }
            } else {
                JOptionPane.showMessageDialog(dialog, "Please select a row to update.");
            }
        });

        btnReset.addActionListener(e -> {
            FileHandler.overwriteFile("grading_default.txt", new ArrayList<>()); 
            checkAndInitGradingDefaults(); 
            model.setRowCount(0); 
            for(String l : FileHandler.readFile("grading_default.txt")) model.addRow(l.split(","));
            JOptionPane.showMessageDialog(dialog, "Reset to defaults completed.");
        });

        btnExit.addActionListener(e -> dialog.dispose());

        pnl.add(btnUpdate);
        pnl.add(btnReset);
        pnl.add(btnExit);
        
        dialog.add(new JScrollPane(table), BorderLayout.CENTER);
        dialog.add(pnl, BorderLayout.SOUTH);
        dialog.setLocationRelativeTo(parent);
        dialog.setVisible(true);
    }

    private void checkAndInitGradingDefaults() {
        List<String> data = FileHandler.readFile("grading_default.txt");
        if(data.isEmpty()) {
            List<String> defaults = new ArrayList<>();
            defaults.add("80,100,A+,4.00,Distinction");
            defaults.add("75,79,A,3.70,Distinction");
            defaults.add("70,74,B+,3.30,Credit");
            defaults.add("65,69,B,3.00,Credit");
            defaults.add("60,64,C+,2.70,Pass");
            defaults.add("55,59,C,2.30,Pass");
            defaults.add("50,54,C-,2.00,Pass");
            defaults.add("40,49,D,1.70,Fail (Marginal)");
            defaults.add("30,39,F+,1.30,Fail");
            defaults.add("20,29,F,1.00,Fail");
            defaults.add("0,19,F-,0.00,Fail");
            FileHandler.overwriteFile("grading_default.txt", defaults);
        }
    }

    private void saveTableDataToFile(DefaultTableModel model, String filename) {
        List<String> newData = new ArrayList<>();
        for (int i = 0; i < model.getRowCount(); i++) {
            StringBuilder row = new StringBuilder();
            for (int j = 0; j < model.getColumnCount(); j++) {
                row.append(model.getValueAt(i, j));
                if (j < model.getColumnCount() - 1) row.append(",");
            }
            newData.add(row.toString());
        }
        FileHandler.overwriteFile(filename, newData);
    }
}