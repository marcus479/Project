

package afs;

import javax.swing.*;
import java.io.File;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        // 1. Set Beautiful Look and Feel (Nimbus)
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            // Fallback to default
        }

        // 2. Initialize System Files (Prevent crash on first run)
        initFiles();

        // 3. Launch Login
        SwingUtilities.invokeLater(() -> new Login().start());
    }

    private static void initFiles() {
        String[] files = {"users.txt", "modules.txt", "classes.txt", "assessments.txt", "grades.txt", "enrollments.txt", "comments.txt", "module_lecturers.txt"};
        for (String f : files) {
            File file = new File(f);
            if (!file.exists()) {
                try {
                    file.createNewFile();
                    // Create Default Admin if users.txt is empty
                    if (f.equals("users.txt")) {
                        FileHandler.appendToFile("users.txt", "admin,admin123,Admin,System Administrator");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}