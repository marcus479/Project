
package afs;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class Student extends User {

    public Student(String id, String password, String name) {
        super(id, password, name, "Student");
    }

    @Override
    public void showDashboard() {
        JFrame frame = new JFrame("Student Dashboard - " + this.name);
        frame.setSize(700, 500);
        frame.setLayout(new BorderLayout());

        // 1. Header
        JLabel lblTitle = new JLabel("Student Portal", SwingConstants.CENTER);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblTitle.setForeground(new Color(50, 50, 50));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        frame.add(lblTitle, BorderLayout.NORTH);

        // 2. Buttons Panel
        JPanel btnPanel = new JPanel(new GridLayout(5, 1, 15, 15));
        btnPanel.setBorder(BorderFactory.createEmptyBorder(20, 60, 40, 60));

        JButton btnRegister = new JButton("Register for Class");
        JButton btnResults = new JButton("Check Results & Grades");
        JButton btnComment = new JButton("Provide Lecturer Comments");
        JButton btnEditProfile = new JButton("Edit Profile");
        JButton btnLogout = new JButton("Logout");

        // Apply Styling (Coral Theme)
        Color themeColor = new Color(255, 127, 80); // Coral
        styleButton(btnRegister, themeColor);
        styleButton(btnResults, themeColor);
        styleButton(btnComment, themeColor);
        styleButton(btnEditProfile, themeColor);
        styleButton(btnLogout, themeColor);

        // --- Feature: Register ---
        btnRegister.addActionListener(e -> {
            String classId = JOptionPane.showInputDialog(frame, "Enter Class ID to register (e.g., APU-CS-01):");
            if (classId != null && !classId.isEmpty()) {
                FileHandler.appendToFile("enrollments.txt", this.id + "," + classId);
                JOptionPane.showMessageDialog(frame, "Registration Successful!");
            }
        });

        // --- Feature: Results ---
        btnResults.addActionListener(e -> {
            List<String> grades = FileHandler.readFile("grades.txt");
            StringBuilder sb = new StringBuilder();
            sb.append(String.format("%-15s %-15s %-10s %-20s\n", "Module", "Assessment", "Mark", "Feedback"));
            sb.append("------------------------------------------------------------\n");
            
            boolean found = false;
            for (String line : grades) {
                String[] p = line.split(",");
                // Ensure data integrity before reading
                if (p.length >= 5 && p[0].equals(this.id)) {
                    sb.append(String.format("%-15s %-15s %-10s %-20s\n", p[1], p[2], p[3], p[4]));
                    found = true;
                }
            }
            if(!found) sb.append("No results found yet.");

            JTextArea area = new JTextArea(sb.toString());
            area.setFont(new Font("Monospaced", Font.PLAIN, 12));
            area.setEditable(false);
            JOptionPane.showMessageDialog(frame, new JScrollPane(area), "My Academic Results", JOptionPane.INFORMATION_MESSAGE);
        });

        // --- Feature: Comments ---
        btnComment.addActionListener(e -> {
            JTextField txtLect = new JTextField();
            JTextField txtMsg = new JTextField();
            Object[] message = { "Lecturer ID:", txtLect, "Comment:", txtMsg };

            int option = JOptionPane.showConfirmDialog(frame, message, "Feedback to Lecturer", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                FileHandler.appendToFile("comments.txt", txtLect.getText() + "," + this.id + "," + txtMsg.getText());
                JOptionPane.showMessageDialog(frame, "Comment Submitted anonymously.");
            }
        });
        
        // --- Feature: Edit Profile
        btnEditProfile.addActionListener(e -> {
            editProfile(frame);
        });

        // --- Feature: Logout ---
        btnLogout.addActionListener(e -> {
            frame.dispose();
            new Login().start();
        });

        btnPanel.add(btnRegister);
        btnPanel.add(btnResults);
        btnPanel.add(btnComment);
        btnPanel.add(btnEditProfile);// 🔐 password only
        btnPanel.add(btnLogout);

        frame.add(btnPanel, BorderLayout.CENTER);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void styleButton(JButton btn, Color color) {
        btn.setFont(new Font("SansSerif", Font.BOLD, 16));
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(color.darker(), 1),
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
    }
}
