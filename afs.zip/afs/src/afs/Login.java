package afs;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.List;

public class Login {

    private BufferedImage backgroundImage;

    public void start() {
        try {
            backgroundImage = ImageIO.read(new File("p2.jpg"));
        } catch (IOException e) {
            System.err.println("Could not load background image: " + e.getMessage());
        }

        JFrame frame = new JFrame("AFS - Assessment Feedback System");
        frame.setMinimumSize(new Dimension(800, 600)); 
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Background Panel
        JPanel mainPanel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                } else {
                    Graphics2D g2d = (Graphics2D) g;
                    GradientPaint gp = new GradientPaint(0, 0, new Color(65, 105, 225), 0, getHeight(), new Color(135, 206, 235));
                    g2d.setPaint(gp);
                    g2d.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        frame.setContentPane(mainPanel);

        // Responsive Login Card
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(new Color(255, 255, 255, 220)); 
        card.setBorder(new EmptyBorder(40, 50, 40, 50)); 

        // UI Components
        JLabel lblHeader = new JLabel("Welcome Back");
        lblHeader.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblHeader.setFont(new Font("SansSerif", Font.BOLD, 28));
        lblHeader.setForeground(new Color(45, 45, 45));

        JLabel lblSub = new JLabel("Please login to continue");
        lblSub.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblSub.setFont(new Font("SansSerif", Font.PLAIN, 14));
        lblSub.setForeground(Color.DARK_GRAY);

        JLabel lblUser = new JLabel("User ID");
        lblUser.setFont(new Font("SansSerif", Font.BOLD, 14));
        JTextField txtUser = new JTextField(20);
        txtUser.setMaximumSize(new Dimension(400, 35));

        JLabel lblPass = new JLabel("Password");
        lblPass.setFont(new Font("SansSerif", Font.BOLD, 14));
        JPasswordField txtPass = new JPasswordField(20);
        txtPass.setMaximumSize(new Dimension(400, 35));

        JButton btnLogin = new JButton("LOGIN");
        btnLogin.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnLogin.setBackground(new Color(30, 144, 255));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFont(new Font("SansSerif", Font.BOLD, 16));
        btnLogin.setPreferredSize(new Dimension(150, 40));
        btnLogin.setMaximumSize(new Dimension(400, 45));
        btnLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));

        card.add(lblHeader);
        card.add(Box.createVerticalStrut(10));
        card.add(lblSub);
        card.add(Box.createVerticalStrut(30));
        card.add(lblUser);
        card.add(Box.createVerticalStrut(5));
        card.add(txtUser);
        card.add(Box.createVerticalStrut(15));
        card.add(lblPass);
        card.add(Box.createVerticalStrut(5));
        card.add(txtPass);
        card.add(Box.createVerticalStrut(30));
        card.add(btnLogin);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(100, 200, 100, 200); 

        mainPanel.add(card, gbc);

        // Login Action
        btnLogin.addActionListener(e -> {
            String uid = txtUser.getText().trim();
            String pwd = new String(txtPass.getPassword()).trim();

            if (uid.isEmpty() || pwd.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill in all fields.", "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }

            User user = authenticate(uid, pwd);
            if (user != null) {
                frame.dispose();
                user.showDashboard();
            } else {
                JOptionPane.showMessageDialog(frame, "Invalid User ID or Password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Key Change: Set the Enter key to trigger btnLogin
        frame.getRootPane().setDefaultButton(btnLogin);

        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private User authenticate(String uid, String pwd) {
        List<String> users = FileHandler.readFile("users.txt");
        for (String line : users) {
            String[] parts = line.split(",");
            if (parts.length >= 4 && parts[0].equals(uid) && parts[1].equals(pwd)) {
                String role = parts[2];
                String name = parts[3];

                switch (role) {
                    case "Admin": return new Admin(uid, pwd, name);
                    case "AcademicLeader": return new AcademicLeader(uid, pwd, name);
                    case "Lecturer": return new Lecturer(uid, pwd, name);
                    case "Student": return new Student(uid, pwd, name);
                }
            }
        }
        return null;
    }
}