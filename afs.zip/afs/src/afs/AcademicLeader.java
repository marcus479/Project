package afs;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class AcademicLeader extends User {

    public AcademicLeader(String id, String password, String name) {
        super(id, password, name, "AcademicLeader");
    }

    @Override
    public void showDashboard() {
        JFrame frame = new JFrame("Academic Leader Dashboard - " + this.name);
        frame.setSize(700, 600); // Increased height for new buttons
        frame.setLayout(new BorderLayout());

        JLabel lblTitle = new JLabel("Academic Module Management", SwingConstants.CENTER);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 22));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));
        frame.add(lblTitle, BorderLayout.NORTH);

        // Updated Grid to fit new buttons (5 rows)
        JPanel mainPanel = new JPanel(new GridLayout(5, 1, 10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        JButton btnManageModules = new JButton("Manage Modules (CRUD)");
        JButton btnAssignLecturer = new JButton("Assign Lecturer to Module");
        JButton btnReports = new JButton("View Analyzed Reports");
        JButton btnProfile = new JButton("Edit Profile");
        JButton btnLogout = new JButton("Logout");

        styleButton(btnManageModules);
        styleButton(btnAssignLecturer);
        styleButton(btnReports);
        styleButton(btnProfile);
        styleButton(btnLogout);

        // --- ACTION: Manage Modules ---
        btnManageModules.addActionListener(e -> openModuleCrudWindow(frame));

        // --- ACTION: Assign Lecturer (With Validation) ---
        btnAssignLecturer.addActionListener(e -> openAssignLecturerWindow(frame));

        // --- ACTION: View Reports ---
        btnReports.addActionListener(e -> showAnalyzedReports(frame));

        // --- ACTION: Edit Profile ---
        btnProfile.addActionListener(e -> editProfile(frame));

        // --- ACTION: Logout ---
        btnLogout.addActionListener(e -> {
            frame.dispose();
            new Login().start();
        });

        mainPanel.add(btnManageModules);
        mainPanel.add(btnAssignLecturer);
        mainPanel.add(btnReports);
        mainPanel.add(btnProfile);
        mainPanel.add(btnLogout);

        frame.add(mainPanel, BorderLayout.CENTER);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    // ==========================================
    // 1. MODULE CRUD (With Exit Button)
    // ==========================================
    private void openModuleCrudWindow(JFrame parent) {
        JDialog dialog = new JDialog(parent, "Manage Modules", true);
        dialog.setSize(600, 400);
        dialog.setLayout(new BorderLayout());

        String[] cols = {"Module Code", "Module Name"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        JTable table = new JTable(model);

        // Load modules
        List<String> modules = FileHandler.readFile("modules.txt");
        for (String m : modules) {
            model.addRow(m.split(","));
        }

        JPanel btnPanel = new JPanel();
        JButton btnAdd = new JButton("Add Module");
        JButton btnEdit = new JButton("Edit Module");
        JButton btnDelete = new JButton("Delete Module");
        JButton btnExit = new JButton("Exit"); // Exit Button

        // Add Logic
        btnAdd.addActionListener(e -> {
            JTextField code = new JTextField();
            JTextField name = new JTextField();
            Object[] msg = {"Module Code:", code, "Module Name:", name};
            if(JOptionPane.showConfirmDialog(dialog, msg, "New Module", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                // Basic Validation
                if(!code.getText().isEmpty()) {
                    String row = code.getText() + "," + name.getText();
                    FileHandler.appendToFile("modules.txt", row);
                    model.addRow(row.split(","));
                }
            }
        });

        // Delete Logic
        btnDelete.addActionListener(e -> {
            int row = table.getSelectedRow();
            if(row != -1) {
                model.removeRow(row);
                saveModules(model);
            } else {
                JOptionPane.showMessageDialog(dialog, "Select a module to delete.");
            }
        });

        // Edit Logic
        btnEdit.addActionListener(e -> {
            int row = table.getSelectedRow();
            if(row != -1) {
                String oldCode = (String)model.getValueAt(row, 0);
                String oldName = (String)model.getValueAt(row, 1);
                
                JTextField nameField = new JTextField(oldName);
                Object[] msg = {"Editing Module " + oldCode, "New Name:", nameField};
                
                if(JOptionPane.showConfirmDialog(dialog, msg, "Edit Module", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                    model.setValueAt(nameField.getText(), row, 1);
                    saveModules(model);
                }
            } else {
                JOptionPane.showMessageDialog(dialog, "Select a module to edit.");
            }
        });

        btnExit.addActionListener(e -> dialog.dispose());

        btnPanel.add(btnAdd);
        btnPanel.add(btnEdit);
        btnPanel.add(btnDelete);
        btnPanel.add(btnExit);

        dialog.add(new JScrollPane(table), BorderLayout.CENTER);
        dialog.add(btnPanel, BorderLayout.SOUTH);
        dialog.setLocationRelativeTo(parent);
        dialog.setVisible(true);
    }

    // ==========================================
    // 2. ASSIGN LECTURER (With Validation & Exit)
    // ==========================================
    private void openAssignLecturerWindow(JFrame parent) {
        JDialog dialog = new JDialog(parent, "Assign Lecturer", true);
        dialog.setSize(400, 300);
        dialog.setLayout(new GridLayout(4, 2, 10, 10));
        
        JTextField txtMod = new JTextField();
        JTextField txtLect = new JTextField();
        JButton btnAssign = new JButton("Assign");
        JButton btnExit = new JButton("Exit");

        dialog.add(new JLabel("Module Code:")); dialog.add(txtMod);
        dialog.add(new JLabel("Lecturer ID:")); dialog.add(txtLect);
        dialog.add(btnAssign); dialog.add(btnExit);

        btnAssign.addActionListener(e -> {
            String modCode = txtMod.getText().trim();
            String lectId = txtLect.getText().trim();

            // VALIDATION: Check if Module Exists
            boolean moduleExists = false;
            List<String> modules = FileHandler.readFile("modules.txt");
            for (String m : modules) {
                String[] parts = m.split(",");
                if (parts.length > 0 && parts[0].equalsIgnoreCase(modCode)) {
                    moduleExists = true;
                    break;
                }
            }

            if (!moduleExists) {
                JOptionPane.showMessageDialog(dialog, "Error: Module '" + modCode + "' does not exist!\nPlease create it first.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // If valid, save
            if (!lectId.isEmpty()) {
                FileHandler.appendToFile("module_lecturers.txt", modCode + "," + lectId);
                JOptionPane.showMessageDialog(dialog, "Lecturer " + lectId + " assigned to " + modCode + "!");
            }
        });

        btnExit.addActionListener(e -> dialog.dispose());

        dialog.setLocationRelativeTo(parent);
        dialog.setVisible(true);
    }

    // ==========================================
    // 3. ANALYZED REPORTS
    // ==========================================
    private void showAnalyzedReports(JFrame parent) {
        // Read data files to generate live stats
        int totalUsers = FileHandler.readFile("users.txt").size();
        int totalModules = FileHandler.readFile("modules.txt").size();
        int totalClasses = FileHandler.readFile("classes.txt").size();
        int totalGrades = FileHandler.readFile("grades.txt").size();

        String report = "=== SYSTEM ANALYZED REPORT ===\n\n" +
                        "Total Registered Users: " + totalUsers + "\n" +
                        "Active Modules: " + totalModules + "\n" +
                        "Classes Created: " + totalClasses + "\n" +
                        "Assessments Graded: " + totalGrades + "\n\n" +
                        "Status: System Operational";

        JTextArea area = new JTextArea(report);
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.BOLD, 14));
        area.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JOptionPane.showMessageDialog(parent, area, "Analyzed Reports", JOptionPane.INFORMATION_MESSAGE);
    }

    private void saveModules(DefaultTableModel model) {
        List<String> data = new ArrayList<>();
        for(int i=0; i<model.getRowCount(); i++) {
            data.add(model.getValueAt(i, 0) + "," + model.getValueAt(i, 1));
        }
        FileHandler.overwriteFile("modules.txt", data);
    }

    private void styleButton(JButton btn) {
        btn.setFont(new Font("SansSerif", Font.PLAIN, 16));
        btn.setBackground(new Color(255, 20, 150)); 
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
    }
}